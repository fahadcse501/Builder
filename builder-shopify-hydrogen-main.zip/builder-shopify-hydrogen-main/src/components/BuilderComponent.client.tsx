import {builder, BuilderComponent} from '@builder.io/react';
import "@builder.io/widgets";

// API key for your Builder space: https://www.builder.io/c/docs/using-your-api-key#finding-your-public-api-key
builder.init('cda38653c81344cf8859bd15e4d8e30d');

export { BuilderComponent };
