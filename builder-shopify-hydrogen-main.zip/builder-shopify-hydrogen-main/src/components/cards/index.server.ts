export {CollectionCard} from './CollectionCard.server';
