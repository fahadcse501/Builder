// Do stuff here
import {BuilderComponent, builder, Builder} from '@builder.io/react';

// API key for your Builder space: https://www.builder.io/c/docs/using-your-api-key#finding-your-public-api-key
builder.init('cda38653c81344cf8859bd15e4d8e30d');

// Add custom components
//
// Builder.registerComponent(Welcome, {
//   name: 'Welcome',
// });

export default BuilderComponent;
